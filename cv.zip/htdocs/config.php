<?php
// config.php - Ne jamais le mettre dans un dossier public
define('BASE_URL', '/www/');

return [
    'host' => 'sql313.byethost13.com',   // l'hôte fourni par ByetHost
    'dbname' => 'b13_39213320_portfolio',    // nom de la base
    'user' => 'b13_39213320',           // root
    'pass' => 'Mmdp2726',               // ""
];